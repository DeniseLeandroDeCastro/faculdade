export const environment = {
  production: false,
  alunoUrl: 'localhost:3000/aluno'
};


