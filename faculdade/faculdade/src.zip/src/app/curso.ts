export class Curso {
  idCurso: number;
  nomeCurso: string;
  numPeriodos: number;
}
